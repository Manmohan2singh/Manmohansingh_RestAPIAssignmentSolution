package com.greatlearning.employeemanagment.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.greatlearning.employeemanagment.entity.Employee;
import com.greatlearning.employeemanagment.exceptions.EmployeeDoesNotExistException;
import com.greatlearning.employeemanagment.exceptions.IdNotFoundException;
import com.greatlearning.employeemanagment.service.EmployeeService;

@RestController
@RequestMapping("/employee")
public class EmployeeController {

	@Autowired
	EmployeeService employeeService;

	@PostMapping("/add-employee")
	public ResponseEntity<Employee> addEmployee(@RequestBody Employee employee) {
		Employee newEmployee = employeeService.addEmployee(employee);
		HttpHeaders header = new HttpHeaders();
		header.add("desc", "New Employee Added !");
//		return ResponseEntity.status(HttpStatus.CREATED).build();
		return ResponseEntity.ok().headers(header).body(newEmployee);
	}

	@GetMapping("/list-all")
	public ResponseEntity<List<Employee>> getAllEmployee() throws EmployeeDoesNotExistException {
		List<Employee> employeeList = employeeService.getAllEmployee();
		return ResponseEntity.ok(employeeList);
	}
	
	@PutMapping("/update-employee")
	public ResponseEntity<String> updateEmployee(@RequestBody Employee employee) throws EmployeeDoesNotExistException {
		employeeService.updateEmployee(employee);
		return ResponseEntity.ok("Updated") ;
	}
	
	@DeleteMapping("/delete-employee/{employeeId}")
	public ResponseEntity<Void> deleteEmployee(@PathVariable int employeeId ) throws IdNotFoundException {
		employeeService.deleteEmployee(employeeId);
		return ResponseEntity.ok().build();
	}
	
	@GetMapping("/get-by-id/{employeeId}")
	public ResponseEntity<Employee> getEmployeeById(@PathVariable int employeeId) throws IdNotFoundException {
		Employee employee = employeeService.getEmployeeById(employeeId);
		return ResponseEntity.ok(employee);
	}
	
	@GetMapping("/sort-asc")
	public ResponseEntity<List<Employee>> getEmployeeAsc() throws EmployeeDoesNotExistException {
		List<Employee> employeeList = employeeService.getSortedEmpAsc();
		return ResponseEntity.ok(employeeList);
	}

	@GetMapping("/sort-desc")
	public ResponseEntity<List<Employee>> getEmployeeDesc() throws EmployeeDoesNotExistException {
		List<Employee> employeeList = employeeService.getSortedEmpDesc();
		return ResponseEntity.ok(employeeList);
	}

}
