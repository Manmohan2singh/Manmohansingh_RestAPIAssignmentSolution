package com.greatlearning.employeemanagment.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.greatlearning.employeemanagment.entity.Employee;
import com.greatlearning.employeemanagment.exceptions.EmployeeDoesNotExistException;
import com.greatlearning.employeemanagment.exceptions.IdNotFoundException;
import com.greatlearning.employeemanagment.service.EmployeeService;

@RestController
@RequestMapping("/employee")
public class EmployeeController {

	@Autowired
	EmployeeService employeeService;

	@PostMapping("/add-employee")
	public ResponseEntity<Employee> addEmployee(@RequestBody Employee employee) {
		Employee newEmployee = employeeService.addEmployee(employee);
		HttpHeaders header = new HttpHeaders();
		header.add("desc", "New Employee Added !");
		return ResponseEntity.ok().headers(header).body(newEmployee);
	}

	@GetMapping("/list-all")
	public ResponseEntity<List<Employee>> getAllEmployee() throws EmployeeDoesNotExistException {
		List<Employee> employeeList = employeeService.getAllEmployee();
		return ResponseEntity.ok(employeeList);
	}

	@PutMapping("/update-employee")
	public ResponseEntity<Employee> updateEmployee(@RequestBody Employee employee)
			throws EmployeeDoesNotExistException {
		Employee updatedEmployee = employeeService.updateEmployee(employee);
		return ResponseEntity.ok(updatedEmployee);
	}

	@DeleteMapping("/delete-employee/{employeeId}")
	public ResponseEntity<String> deleteEmployee(@PathVariable int employeeId) throws IdNotFoundException {
		employeeService.deleteEmployee(employeeId);
		return ResponseEntity.ok("Deleted");
	}

	@GetMapping("/get-employee/{employeeId}")
	public ResponseEntity<Employee> getEmployeeById(@PathVariable int employeeId) throws IdNotFoundException {
		Employee employee = employeeService.getEmployeeById(employeeId);
		return ResponseEntity.ok(employee);
	}

	@GetMapping("/get-by-firstname/{firstName}")
	public ResponseEntity<List<Employee>> getByFirstName(@PathVariable String firstName)
			throws EmployeeDoesNotExistException {
		List<Employee> employeeList = employeeService.getEmployeeByFirstName(firstName);
		return ResponseEntity.ok(employeeList);
	}

	@GetMapping("/sort-asc")
	public ResponseEntity<List<Employee>> sortAsc() throws EmployeeDoesNotExistException {
		List<Employee> employeeList = employeeService.getSortedEmployeeAsc();
		return ResponseEntity.ok(employeeList);
	}

	@GetMapping("/sort-desc")
	public ResponseEntity<List<Employee>> sortDesc() throws EmployeeDoesNotExistException {
		List<Employee> employeeList = employeeService.getSortedEmployeeDesc();
		return ResponseEntity.ok(employeeList);
	}
}
