package com.greatlearning.employeemanagment.exceptions;

public class EmployeeDoesNotExistException extends Exception {

	public EmployeeDoesNotExistException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public EmployeeDoesNotExistException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}
