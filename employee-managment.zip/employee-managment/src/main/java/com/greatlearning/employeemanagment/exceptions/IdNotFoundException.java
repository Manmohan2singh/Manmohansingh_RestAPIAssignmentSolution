package com.greatlearning.employeemanagment.exceptions;

public class IdNotFoundException extends Exception {

	public IdNotFoundException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public IdNotFoundException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}
