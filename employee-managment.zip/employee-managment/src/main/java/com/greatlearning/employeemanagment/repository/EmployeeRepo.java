package com.greatlearning.employeemanagment.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.greatlearning.employeemanagment.entity.Employee;

@Repository
public interface EmployeeRepo extends JpaRepository<Employee, Integer> {
	
	@Query("select a from Employee a where a.firstName = ?1")
	List<Employee> getByFirstname(String firstName);
	
	@Query("select a from Employee a order by a.firstName desc")
	List<Employee> getSortedBydesc();

	@Query("select a from Employee a order by a.firstName")
	List<Employee> getSortedByasc();
}
