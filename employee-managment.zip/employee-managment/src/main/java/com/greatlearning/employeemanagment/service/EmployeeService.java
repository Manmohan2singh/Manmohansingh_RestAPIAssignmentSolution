package com.greatlearning.employeemanagment.service;

import java.util.List;

import com.greatlearning.employeemanagment.entity.Employee;
import com.greatlearning.employeemanagment.exceptions.EmployeeDoesNotExistException;
import com.greatlearning.employeemanagment.exceptions.IdNotFoundException;

public interface EmployeeService {
	public Employee addEmployee(Employee employee);

	public Employee updateEmployee(Employee employee) throws EmployeeDoesNotExistException;

	public void deleteEmployee(int employeeId) throws IdNotFoundException;

	List<Employee> getAllEmployee() throws EmployeeDoesNotExistException;

	public Employee getEmployeeById(int employeeId) throws IdNotFoundException;
	
	List<Employee> getEmployeeByFirstName(String firstName) throws EmployeeDoesNotExistException;
	
	List<Employee> getSortedEmployeeAsc() throws EmployeeDoesNotExistException;
	
	List<Employee> getSortedEmployeeDesc() throws EmployeeDoesNotExistException;

}
