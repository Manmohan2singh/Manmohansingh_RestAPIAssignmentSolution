package com.greatlearning.employeemanagment.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.greatlearning.employeemanagment.entity.Employee;
import com.greatlearning.employeemanagment.exceptions.EmployeeDoesNotExistException;
import com.greatlearning.employeemanagment.exceptions.IdNotFoundException;
import com.greatlearning.employeemanagment.repository.EmployeeRepo;

@Service
public class EmployeeServiceImpl implements EmployeeService {

	@Autowired
	EmployeeRepo employeeRepo;

//add new employee
	@Override
	public Employee addEmployee(Employee employee) {
		return employeeRepo.save(employee);
	}

//update existing employee
	@Override
	public Employee updateEmployee(Employee employee) throws EmployeeDoesNotExistException {
		try {
			return employeeRepo.save(employee);
		} catch (Exception e) {
			System.out.println(e.getMessage());
			throw new EmployeeDoesNotExistException("Employee Does Not Exist");
		}

	}

//delete existing employee
	@Override
	public void deleteEmployee(int employeeId) throws IdNotFoundException {
		try {
			employeeRepo.deleteById(employeeId);
		} catch (Exception e) {
			System.out.println(e.getMessage());
			throw new IdNotFoundException("Invalid Employee Id");
		}

	}

//List all existing employee
	@Override
	public List<Employee> getAllEmployee() throws EmployeeDoesNotExistException {
		List<Employee> employeeList = employeeRepo.findAll();
		if (employeeList.isEmpty())
			throw new EmployeeDoesNotExistException("No Employee Exist !");
		return employeeList;
	}

//get existing employee by their employeeId
	@Override
	public Employee getEmployeeById(int employeeId) throws IdNotFoundException {
		Employee employee;
		try {
			employee = employeeRepo.findById(employeeId).get();
		} catch (Exception e) {
			System.out.println(e.getMessage());
			throw new IdNotFoundException("Invalid Employee Id");
		}
		return employee;
	}

//get all employees with a given first name
	@Override
	public List<Employee> getEmployeeByFirstName(String firstName) throws EmployeeDoesNotExistException {
		List<Employee> employeeList = employeeRepo.getByFirstname(firstName);
		if (employeeList == null)
			throw new EmployeeDoesNotExistException("No Employee With the first name : " + firstName);
		return employeeList;
	}

	@Override
	public List<Employee> getSortedEmployeeAsc() throws EmployeeDoesNotExistException {
		List<Employee> employeeList = employeeRepo.sortFirstNameAsc();
		if(employeeList == null) {
			throw new EmployeeDoesNotExistException("No Employee Exist !");
		}
		return employeeList;
	}
	
	@Override
	public List<Employee> getSortedEmployeeDesc() throws EmployeeDoesNotExistException {
		List<Employee> employeeList = employeeRepo.sortFirstNameDesc();
		if(employeeList == null) {
			throw new EmployeeDoesNotExistException("No Employee Exist !");
		}
		return employeeList;
	}


}
