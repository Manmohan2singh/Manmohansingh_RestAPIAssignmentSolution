package com.greatlearning.employeemanagment.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.greatlearning.employeemanagment.entity.Employee;
import com.greatlearning.employeemanagment.exceptions.EmployeeDoesNotExistException;
import com.greatlearning.employeemanagment.exceptions.IdNotFoundException;
import com.greatlearning.employeemanagment.repository.EmployeeRepo;

@Service
public class EmployeeServiceImpl implements EmployeeService {

	@Autowired
	EmployeeRepo employeeRepo;

//add new employee
	@Override
	public Employee addEmployee(Employee employee) {
		return employeeRepo.save(employee);
	}

//update existing employee
	@Override
	public void updateEmployee(Employee employee) throws EmployeeDoesNotExistException {
		try {
			employeeRepo.save(employee);
		} catch (Exception e) {
			System.out.println(e.getMessage());
			throw new EmployeeDoesNotExistException("Employee Does Not Exist");
		}

	}

//delete existing employee
	@Override
	public void deleteEmployee(int employeeId) throws IdNotFoundException {
		try {
			employeeRepo.deleteById(employeeId);
		} catch (Exception e) {
			System.out.println(e.getMessage());
			throw new IdNotFoundException("Invalid Employee Id");
		}

	}

//List all existing employee
	@Override
	public List<Employee> getAllEmployee() throws EmployeeDoesNotExistException {
		List<Employee> employeeList = employeeRepo.findAll();
		if (employeeList.isEmpty())
			throw new EmployeeDoesNotExistException("No Employee Exist !");
		return employeeList;
	}

//get existing employee by their employeeId
	@Override
	public Employee getEmployeeById(int employeeId) throws IdNotFoundException {
		Employee employee;
		try {
			employee = employeeRepo.getById(employeeId);
		} catch (Exception e) {
			System.out.println(e.getMessage());
			throw new IdNotFoundException("Invalid Employee Id");
		}
		return employee;
	}

//get all employees with a given first name
	@Override
	public List<Employee> getEmployeeByFirstName(String firstName) throws EmployeeDoesNotExistException {
		List<Employee> employeeList = employeeRepo.getByFirstname(firstName);
		if (employeeList == null)
			throw new EmployeeDoesNotExistException("No Employee With the first name : " + firstName);
		return employeeList;
	}

	//get all employees sorted on their first name
	@Override
	public List<Employee> getSortedEmpAsc() throws EmployeeDoesNotExistException {
		List<Employee> employeeList = employeeRepo.getSortedByasc();
		if (employeeList == null) {
			throw new EmployeeDoesNotExistException("employee Does Not Exist");
		}
		return employeeList;
	}

	@Override
	public List<Employee> getSortedEmpDesc() throws EmployeeDoesNotExistException {
		List<Employee> employeeList = employeeRepo.getSortedBydesc();
		if (employeeList == null) {
			throw new EmployeeDoesNotExistException("employee Does Not Exist");
		}
		return employeeList;
	}


}
