package com.greatlearning.employeemanagment.service;

import org.springframework.beans.factory.annotation.Autowired;
import com.greatlearning.employeemanagment.entity.User;
import com.greatlearning.employeemanagment.repository.UserRepo;
import com.greatlearning.employeemanagment.security.UserDetails;

public class UserServiceImpl implements UserDetailsService {

	@Autowired
	UserRepo userRepo;
	
	@Override
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
		User user = userRepo.getByUsername(username) ;
		if(user == null) {
			throw new UsernameNotFoundException("User Does Not Exist !");
		}
		return new com.greatlearning.employeemanagment.security.UserDetails(user);
	}

}
